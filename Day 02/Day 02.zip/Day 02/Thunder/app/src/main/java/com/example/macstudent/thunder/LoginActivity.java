package com.example.macstudent.thunder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{


    Button btnLogin;
    Button btnRegistration;
    EditText edtUsername;
    EditText edtPassword;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegistration = (Button) findViewById(R.id.btnRegistration);
        btnRegistration.setOnClickListener(this);

        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId()){
            String uname = edtUsername.getText().toString();
            String passwrd = edtPassword.getText().toString();

            if(uname.equals("test") && passwrd.equals("test")){
                Toast.makeText( this, uname + passwrd + " Login clicked",Toast.LENGTH_LONG).show();


                Intent homeIntent = new Intent(this, HomeActivity.class);
                startActivity(homeIntent);
            }
        }else if(view.getId() == btnRegistration.getId()){
            //Toast.makeText(this, "Register clicked", Toast.LENGTH_SHORT).show();

            Intent registerIntent = new Intent(this, RegisterActivity.class);
            startActivity(registerIntent);
        }
    }
}
