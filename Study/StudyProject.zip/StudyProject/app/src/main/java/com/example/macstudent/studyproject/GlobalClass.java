package com.example.macstudent.studyproject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by macstudent on 2018-04-11.
 */

public class GlobalClass {

    static String Name = "ola";

    static ArrayList<Person> listPerson = new ArrayList<Person>();

    static void showClass(){

    }
}
