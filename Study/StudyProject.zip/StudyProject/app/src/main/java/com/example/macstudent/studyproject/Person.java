package com.example.macstudent.studyproject;

/**
 * Created by macstudent on 2018-04-11.
 */

public class Person {
    String Name;
    String Surname;
}
