package com.example.macstudent.studyproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonRedirect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonRedirect = (Button)findViewById(R.id.btnMainRedirect);
        buttonRedirect.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.btnMainRedirect:
                GlobalClass.Name = "Caio";

                Intent redirectPage = new Intent(getApplicationContext(), SecondActivity.class);
                startActivity(redirectPage);
                break;
            default:
                break;
        }
    }
}
