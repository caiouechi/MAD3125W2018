package com.jk.thunder;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.Map;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin;
    Button btnRegister;
    EditText edtUsername;
    EditText edtPassword;

    DBHelper dbHelper;
    SQLiteDatabase thunderDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnLogin.getId()) {
//            String uname = edtUsername.getText().toString();
//            String passwd = edtPassword.getText().toString();
//
//            if(uname.equals("test") && passwd.equals("test")) {
//                Toast.makeText(this,
//                        "Login successful",
//                        Toast.LENGTH_LONG).show();
//
//                Intent homeIntent = new Intent
//                        (this,HomeActivity.class);
//                startActivity(homeIntent);
//
//            }

            if (verifyLogin()) {
                finish();
                Intent homeIntent = new Intent
                        (this, HomeActivity.class);
                startActivity(homeIntent);
            } else {
                Toast.makeText(this,
                        "Invalid username / password",
                        Toast.LENGTH_LONG).show();
            }

        } else if (view.getId() == btnRegister.getId()) {
//            Toast.makeText(this,
//                    "Register Clicked",
//                    Toast.LENGTH_SHORT).show();

            Intent registerIntent = new Intent
                    (this, RegisterActivity.class);
            startActivity(registerIntent);
        }
    }

    private boolean verifyLogin(){
            try{
                thunderDB = dbHelper.getReadableDatabase();
                String columns[] = {"Email", "Password"};

                ArrayList<User> newArrayList = new ArrayList<User>();

                Cursor cursor = thunderDB.query(
                        "UserInfo", columns, null, null,
                        null,null,null);

                if (cursor != null){
                    if (cursor.getCount() > 0){
                        while (cursor.moveToNext()) {
                            User newUser = new User();
                            newUser.Email = cursor.getString(cursor.getColumnIndex("Email"));
                            newUser.Password = cursor.getString(cursor.getColumnIndex("Password"));
                            newArrayList.add(newUser);
                        }
                        return true;
                    }
                }

                return false;

            }catch(Exception ex){
                Log.e("LoginActivity","Something wrong with database connection");
                return false;
            }finally {
                thunderDB.close();
            }
    }
}

