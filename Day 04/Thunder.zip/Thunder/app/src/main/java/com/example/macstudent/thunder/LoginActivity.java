package com.example.macstudent.thunder;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{


    Button btnLogin;
    Button btnRegistration;
    EditText edtUsername;
    EditText edtPassword;

    DBHelper dbHelper;
    SQLiteDatabase thunderDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegistration = (Button) findViewById(R.id.btnRegistration);
        btnRegistration.setOnClickListener(this);

        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId()){
            String uname = edtUsername.getText().toString();
            String passwrd = edtPassword.getText().toString();



           if(verifyLogin()){

               Intent homeIntent = new Intent(this, HomeActivity.class);
               startActivity(homeIntent);
               finish();
           }
        }else if(view.getId() == btnRegistration.getId()){
            //Toast.makeText(this, "Register clicked", Toast.LENGTH_SHORT).show();

            Intent registerIntent = new Intent(this, RegisterActivity.class);
            startActivity(registerIntent);
        }
    }

    private boolean verifyLogin(){
        try{
thunderDB = dbHelper.getReadableDatabase();
String columns[] = {"Email", "Password"};

Cursor cursor = thunderDB.query("UserInfo", columns,
        "Email = ? and Password = ?",
        new String[]{edtUsername.getText().toString(), edtPassword.getText().toString()}, null,null,null);

            if (cursor != null){
                if(cursor.getCount() > 0){
                    return true;
                }

            }

            return false;

        }catch(Exception ex){
            Log.e("LoginActivity", "Something",null);
            thunderDB.close();
            return false;
        }
    }
}
